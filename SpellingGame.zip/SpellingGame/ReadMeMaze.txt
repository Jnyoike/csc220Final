JsOsaDAS1.001.00bplist00�Vscript_�//README: Spelling Maze Game

//In order to run this game, the user needs to install a version of Processing 3. For this prototype, we found a randomized maze generator from https://www.openprocessing.org/sketch/81079. To start this project, we edited the code to have a letter image randomly generate in a cell somewhere in the maze; however, to ensure that the user is not forced to collect a letter that is not in the right order, we ensure that the letter produced is not found in any of the cells that are part of the correct path from the start to the end cell. If the ball touched the image, the image would disappear.

//Known logical errors:
//have the key values in the dictonary match to which image files that needs to be produced on the maze.
//Save the letters that the user picks up in the order in which they touch the letters to spell out the defined word. 
//The positioning of the letter in the higher level mazes is not moving in accordance to the change of the maze size.                               � jscr  ��ޭ